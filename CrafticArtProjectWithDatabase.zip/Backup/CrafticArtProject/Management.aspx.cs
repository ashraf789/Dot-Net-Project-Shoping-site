﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace CrafticArtProject
{
    public partial class Management : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SUBMITButton1_Click(object sender, EventArgs e)
        {
          

            if (USER_NAMEtxt.Text == "admin" && PASSWORDtxt.Text == "123" || USER_NAMEtxt.Text == "shamrat" && PASSWORDtxt.Text == "1234")
            {

                Response.Redirect("~/CUSTOMER_PRODUCT.aspx");
            }
            else { 
            
            //Alert.Show("invalid id or password");
            }
        }
    }
}