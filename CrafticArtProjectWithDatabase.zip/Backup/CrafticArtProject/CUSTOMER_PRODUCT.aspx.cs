﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrafticArtProject
{
    public partial class CUSTOMER_PRODUCT : System.Web.UI.Page
    {
        CrafticArtProject ob = new CrafticArtProject();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack) { 
                loadGrid();
                loadGrid1();
            }
        }


        //SELECT DATA TO LOADGRID
        public void loadGrid()
        {

            string query = @"SELECT [PRODUCT_ID]
      ,[PRODUCT_NAME]
      ,[PRODUCT_CATEGORY]
      ,[PRODUCT_DESCRIPTION]
      ,[PRODUCT_PRICE]
      ,[PRODUCT_IMAGE]
  FROM [dbo].[PRODUCT_DETAILS]";
            PRODUCTGRIDVIEW.DataSource = ob.getDataTable(query);
            PRODUCTGRIDVIEW.DataBind();
        }



        //INSERT DATA
        protected void Button1_Click1(object sender, EventArgs e)
        {
            if (!FileUpload1.HasFile)
            {

            }
            else
            {
                string strname = FileUpload1.FileName;
                FileUpload1.PostedFile.SaveAs(Server.MapPath(".") + "//Upload//" + strname);
                string path = "~//Upload//" + strname.ToString();
                string query = @"INSERT INTO [dbo].[PRODUCT_DETAILS]
           ([PRODUCT_ID]
           ,[PRODUCT_NAME]
           ,[PRODUCT_CATEGORY]
           ,[PRODUCT_DESCRIPTION]
           ,[PRODUCT_PRICE]
           ,[PRODUCT_IMAGE])
     VALUES
           ('" + PRODUCT_IDtxt.Text + "','" + PRODUCT_NAMEtxt.Text + "','" + PRODUCT_CATEGORYDDLIST.SelectedItem.Text + "', '" + PRODUCT_DESCRIPTIONtxt.Text + "', '" + PRODUCT_PRICEtxt.Text + "','" + path + "')";

                ob.executeQuery(query);
                loadGrid();
            }
        }




        //DELETE ONE
        protected void Button2_Click(object sender, EventArgs e)
        {
            string query = @"DELETE FROM [dbo].[PRODUCT_DETAILS]
      WHERE PRODUCT_ID='"+PRODUCT_IDtxt.Text+"'";

            if (ob.executeQuery(query) == 1) {
                loadGrid();
            }
        }





        //DELETE ALL
        protected void Button3_Click(object sender, EventArgs e)
        {
            string query = @"DELETE FROM [dbo].[PRODUCT_DETAILS]";
            if (ob.executeQuery(query) == 1) {
                loadGrid();
            }
        }





        //UPDATE
        protected void Button4_Click(object sender, EventArgs e)
        {
            string query = @"UPDATE [dbo].[PRODUCT_DETAILS]
   SET 
      [PRODUCT_NAME] = <PRODUCT_NAME, nvarchar(50),>
      ,[PRODUCT_CATEGORY] = <PRODUCT_CATEGORY, nvarchar(50),>
      ,[PRODUCT_DESCRIPTION] = <PRODUCT_DESCRIPTION, nvarchar(max),>
 WHERE PRODUCT_ID='"+PRODUCT_IDtxt.Text+"'";

            if (ob.executeQuery(query) == 1) {
                loadGrid();
            }
        }






//CUSTOMER_ORDER CODE

        public void loadGrid1()
        {

            string query = @"SELECT [CUSTOMER_ID]
      ,[PRODUCT_ID]
      ,[CUSTOMER_NAME]
      ,[CUSTOMER_ADDRESS]
      ,[CUSTOMER_PHONE_NUMBER]
      ,[ORDER_DATE]
      ,[PRODUCT_QUANTITY]
  FROM [dbo].[CUSTOMER_ORDER]";
            CUSTOMER_ORDER.DataSource = ob.getDataTable(query);
            CUSTOMER_ORDER.DataBind();
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            string query = @"DELETE FROM [dbo].[CUSTOMER_ORDER]
      WHERE CUSTOMER_ID='"+DELETE_CUSTOMER_INFOtxt.Text+"'";

            if (ob.executeQuery(query) == 1) {
                loadGrid1();
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            String query = @"DELETE FROM [dbo].[CUSTOMER_ORDER]";

            if(ob.executeQuery(query)==1){
                loadGrid1();
            }
        }






        //VENDOR_ PAGE CODE

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/VENDOR.aspx");
        }
        
    }
}