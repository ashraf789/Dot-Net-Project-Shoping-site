﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrafticArtProject.Dashboard
{
    public partial class CustomerOrder : System.Web.UI.Page
    {
        CrafticArtProject ob = new CrafticArtProject();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack) loadGrid();
        }

        public void loadGrid()
        {

            string query = @"SELECT * FROM CUSTOMER_ORDER";
            grideOrderView.DataSource = ob.getDataTable(query);
            grideOrderView.DataBind();
        }
    }
}