﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrafticArtProject
{
    public partial class OldProduct : System.Web.UI.Page
    {
        CrafticArtProject ob = new CrafticArtProject();

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
                loadGrid();
        }

        public void loadGrid()
        {

            string query = @"SELECT * FROM PRODUCT_DETAILS";
            PRODUCTGRIDVIEW.DataSource = ob.getDataTable(query);
            PRODUCTGRIDVIEW.DataBind();
        }



        protected void PRODUCTGRIDVIEW_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Label lbl = (Label)PRODUCTGRIDVIEW.Rows[e.RowIndex].FindControl("lblId");
            TextBox tvName = (TextBox)PRODUCTGRIDVIEW.Rows[e.RowIndex].FindControl("txtName");
            TextBox tvCatagori = (TextBox)PRODUCTGRIDVIEW.Rows[e.RowIndex].FindControl("txtCatagori");
            TextBox tvDetails = (TextBox)PRODUCTGRIDVIEW.Rows[e.RowIndex].FindControl("txtDetails");
            TextBox tvPrice = (TextBox)PRODUCTGRIDVIEW.Rows[e.RowIndex].FindControl("txtPrice");

            String _query = @"UPDATE [CrafticArtProject].[dbo].[PRODUCT_DETAILS] SET [PRODUCT_NAME] = '"+tvName.Text+"',[PRODUCT_CATEGORY] = '"+tvCatagori.Text+"',[PRODUCT_DESCRIPTION] = '"+tvDetails.Text+"',[PRODUCT_PRICE] ='"+tvPrice.Text+"' WHERE PRODUCT_ID='"+lbl.Text+"'";

            int status = ob.executeQuery(_query);
            if (status >= 1)
            {
                Response.Write("Data Update Successfully");
                PRODUCTGRIDVIEW.EditIndex = -1;
                loadGrid();

            }
            else
            {
                Response.Write("Data Update Faild");
            }

        }

        protected void PRODUCTGRIDVIEW_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label lbl = (Label)PRODUCTGRIDVIEW.Rows[e.RowIndex].FindControl("lblId");
            String _query = @"Delete From PRODUCT_DETAILS Where PRODUCT_ID='" + lbl.Text + "'";

            int status = ob.executeQuery(_query);
            if (status >= 1)
            {
                Response.Write("Data Delete Successfully");
            }
            else
            {
                Response.Write("Data Is not Delete");
            }

            loadGrid();
        }

        protected void PRODUCTGRIDVIEW_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            PRODUCTGRIDVIEW.EditIndex = -1;
            loadGrid();
        }

        protected void PRODUCTGRIDVIEW_RowEditing(object sender, GridViewEditEventArgs e)
        {
            PRODUCTGRIDVIEW.EditIndex = e.NewEditIndex;
            loadGrid();
        }
    }
}