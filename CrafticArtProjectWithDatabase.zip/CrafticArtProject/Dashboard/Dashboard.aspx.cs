﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrafticArtProject
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        CrafticArtProject ob = new CrafticArtProject();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSend_Click(object sender, EventArgs e)
        {


            if (string.IsNullOrWhiteSpace(txtProductId.Text)
                || string.IsNullOrWhiteSpace(txtProductName.Text)
                || string.IsNullOrWhiteSpace(Catagori.SelectedItem.Text)
                || string.IsNullOrWhiteSpace(txtProductDetails.Text)
                || string.IsNullOrWhiteSpace(txtProductPrice.Text)
                || !FileUpload1.HasFile
                )
            {
                showPopUp("Datafield can,t be empty");
            }
            else
            {
                string strname = FileUpload1.FileName;
                FileUpload1.PostedFile.SaveAs(Server.MapPath(".") + "//../Upload//" + strname);
                string path = "~///Upload//" + strname.ToString();

                string query = @"INSERT INTO [dbo].[PRODUCT_DETAILS]
                       ([PRODUCT_ID]
                       ,[PRODUCT_NAME]
                       ,[PRODUCT_CATEGORY]
                       ,[PRODUCT_DESCRIPTION]
                       ,[PRODUCT_PRICE]
                       ,[PRODUCT_IMAGE])
                 VALUES
                       ('" + txtProductId.Text + "','" + txtProductName.Text + "','" + Catagori.SelectedItem.Text + "', '" + txtProductDetails.Text + "', '" + txtProductPrice.Text + "','" + path + "')";

                if (ob.executeQuery(query) == 1)
                {
                    showPopUp("Successfully send your order request");
                }
                else
                {
                    showPopUp("Some thing is wrong please insert data carefully ");
                }
                
            }
            
        }

        public void showPopUp(String str) {
            Response.Write("<script>alert('"+str+"');</script>");
        }
        
    }
}